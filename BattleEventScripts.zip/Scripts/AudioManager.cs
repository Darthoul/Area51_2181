﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour {

    static public AudioManager instance;
    public AudioSource bgmTrack;
    public List<AudioClip> bgmClipList;

    int currentBgmTarget;

    void Awake () {
        if (instance == null) {
            instance = this;
        }
    }

    public void SetBGMChange (int targetBgm) {
        PlayOnBGMTrack (targetBgm);
    }

    public void ReturnBgm () {
        PlayOnBGMTrack (currentBgmTarget);
    }

    void PlayOnBGMTrack(int index) {
        if (bgmTrack.isPlaying) { bgmTrack.Stop(); }
        bgmTrack.clip = bgmClipList[index];
        bgmTrack.Play ();
    }
}
