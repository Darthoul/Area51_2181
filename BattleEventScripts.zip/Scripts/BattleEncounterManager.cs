﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleEncounterManager : MonoBehaviour {

    static public BattleEncounterManager instance;

    int bgmIndex = -1;
    List<Enemy> enemyGroup;

    string endConditions;

    void Awake () {
        if (instance == null){
            instance = this;
        }
    }

    // Use this for re-initialization
    void OnEnable () {
        AudioManager.instance.SetBGMChange (bgmIndex);
	}
	
	void Update () {
        //CALL ANY METHODS NEEDED FOR ENCOUNTER

        if (CheckEndConditions(out endConditions)) {
            //DO SOMETHING WITH CONDITIONS
            enabled = false;
        }
	}

    void OnDisable () {
        endConditions = null;
        enemyGroup = null;
        bgmIndex = -1;
        AudioManager.instance.ReturnBgm ();
    }

    bool CheckEndConditions (out string checkOutput) {
        checkOutput = "";
        return true;
    }

    static public void MakeEvent (List<Enemy> targetGroup, int bgmIndex) {
        instance.enabled = true;
        instance.enemyGroup = new List<Enemy> (targetGroup);
        instance.bgmIndex = bgmIndex;
    }
}
